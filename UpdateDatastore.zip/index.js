/**
 * Background Cloud Function to be triggered by Pub/Sub.
 * This function is exported by index.js, and executed when
 * the trigger topic receives a message.
 *
 * @param {object} data The event payload.
 * @param {object} context The event metadata.
 */
exports.updateDataStore = (data, context) => {
  const Datastore = require('@google-cloud/datastore');
  const pubSubMessage = data;
  var  attributes = pubSubMessage.attributes;
  console.log('attributes '+attributes);

  var id = attributes.id;
  var iname = attributes.name;
  var ip = attributes.ip;
  var projId = attributes.projectId;
  var action = attributes.action;

  const datastore = new Datastore({
  	projectId: projId,
	});
  
  const kind = 'cloud_automation';
  const taskKey = datastore.key(kind);
  var currentTime = new Date().getTime();
  var data = {
      timestamp: ''+currentTime,
      operation: action,
      ip: ip,
      name: iname
    };

  const task = {
    key: taskKey,
    data: data
  };

  datastore
    .save(task)
    .then(() => {
      console.log(`Saved ${task.key.name}: ${task.data.description}`);
    })
    .catch(err => {
      console.error('ERROR:', err);
    });
  
  
  
  const query = datastore
      .createQuery('cloud_automation')
      .order('timestamp', {
        ascending: true,
      });
	  
  
datastore.runQuery(query).then(results => {
       const tasks = results[0];

      console.log('Tasks:');
      tasks.forEach(task => console.log(task));
	  
	  for(var task in tasks)
	  {
		  
	  }
	  
    });
};


