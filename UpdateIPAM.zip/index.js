/**
 * Background Cloud Function to be triggered by Pub/Sub.
 * This function is exported by index.js, and executed when
 * the trigger topic receives a message.
 *
 * @param {object} data The event payload.
 * @param {object} context The event metadata.
 */
exports.createInstance = (data, context) => {
  const pubSubMessage = data;
  var  attributes = pubSubMessage.attributes;
  console.log('attributes '+attributes);

  var orgName = "Internal";
  var domainName = "tcpwave.com";
  var objectType = "GCE Instance";
  var hostIp = "www4.tcpwave.com";
  var ttl = "1200";
  var id = attributes.id;
  var iname = attributes.name;
  var ip = attributes.ip;
  var action = attributes.action;

  if(attributes.orgName)
  {
	  orgName = attributes.orgName;
  }
  if(attributes.domainName)
  {
	  domainName = attributes.domainName;
  }
  if(attributes.ttl)
  {
	  ttl = attributes.ttl;
  }
  var ipArr = ip.split(".");

  var path = '/tims/rest/object/add';
  if(action == 'add')
  {
    path = '/tims/rest/object/add';
  }
  else
  {
    path = '/tims/rest/object/delete-multiple';
  }
  var reqData = {};
  if(action == 'add')
  {
	  reqData.addr1 = ipArr[0];
	  reqData.addr2 = ipArr[1];
	  reqData.addr3 = ipArr[2];
	  reqData.addr4 = ipArr[3];
	  reqData.class_code = objectType;
	  reqData.domain_name = domainName;
	  reqData.ttl = ttl;
	   reqData.name = iname;
	  reqData.alloc_type = "1";
	  reqData.organization_name = orgName;
	  reqData.dyn_update_rrs_a = true;
	  reqData.dyn_update_rrs_cname = true;
	  reqData.dyn_update_rrs_mx = true;
	  reqData.dyn_update_rrs_ptr = true;
	  reqData.update_ns_a = true;
	  reqData.update_ns_ptr = true;
  }
  else
  {
	  var addrArr = [ip];
	  reqData.addressArray = addrArr;
	  reqData.organization_name = orgName;
  }

  var https = require('https');
  const tls = require('tls');
  var fs = require('fs');
  var options = {
    host: hostIp,
    port: '7443',
    path: path,
    method: 'POST',
    key: fs.readFileSync('client.key'),
    cert: fs.readFileSync('client.crt')
   };

  process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
  var postHeaders = {'Content-Type':'application/json',"user-agent": "curl/7.43.0 AppEngine-Google; (+http://code.google.com/appengine; appid: s~gcf-http-proxy)"};
 var jsonObject;
  if ( reqData )
  {
    jsonObject = JSON.stringify(reqData);
  }
  if ( jsonObject )
  {
    console.log(' ');
    console.log(jsonObject);
    postHeaders["Content-Length"] = Buffer.byteLength(jsonObject, 'utf8');
  }
  options.headers = postHeaders;
  console.log("Headers:"+postHeaders);
  var reqPost = https.request(options, function(res){
  console.log("Status Code: ", res.statusCode);
    res.on('data', function(d){
      process.stdout.write(d);
    });
  });
if ( jsonObject )
  reqPost.write(jsonObject);
else
  reqPost.write("{}");

  reqPost.on('error', function(e){
    console.error('Error: '+e);
  });

};

